package com.example.app9weather.data;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;

public class WeatherResponse {
    public Response response;
    public String chaneOfRain = "";
    public String skyStatus = "";
    public String temperature = "";

    public void parse() {
        String currentTime = new SimpleDateFormat("HH").format(new java.util.Date()) + "00";

        response.body.items.item.stream().filter(new Predicate<Item>() {
            @Override
            public boolean test(Item item) {
                return (item.fcstTime.equals(currentTime));
            }
        }).forEach(new Consumer<Item>() {
            @Override
            public void accept(Item item) {
                switch (item.category) {
                    case "POP": // 강수확률 %
                        chaneOfRain = item.fcstValue;
                        break;
                    case "SKY": // 하늘상태
                        skyStatus = getSKYCode(item.fcstValue);
                        break;
                    case "TMP": // 온도
                        temperature = item.fcstValue;
                }
            }
        });
    }

    private String getSKYCode(String code) {
        String result = "";

        switch(code) {
            case "1":
                result = "맑음";
                break;
            case "3":
                result = "구름많음";
                break;
            case "4":
                result = "흐림";
                break;
            default:
                result = "-";
                break;
        }

        return result;
    }

    public class Body {
        public String dataType;
        public Items items;
        public int pageNo;
        public int numOfRows;
        public int totalCount;
    }

    public class Header {
        public String resultCode;
        public String resultMsg;
    }

    public class Item {
        public String baseDate;
        public String baseTime;
        public String category;
        public String fcstDate;
        public String fcstTime;
        public String fcstValue;
        public String obsrValue;
        public int nx;
        public int ny;
    }

    public class Items {
        public ArrayList<Item> item;
    }

    public class Response {
        public Header header;
        public Body body;
    }
}
