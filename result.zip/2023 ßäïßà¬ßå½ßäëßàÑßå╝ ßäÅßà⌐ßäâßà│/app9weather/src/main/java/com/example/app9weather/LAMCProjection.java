package com.example.app9weather;

import java.util.Map;

public class LAMCProjection {
    private static final double DEGRAD = Math.PI / 180.0;
    private static final double RADDEG = 180.0 / Math.PI;
    private static final double PI = Math.PI;
    static private double Re = 6371.00877; // 지도반경
    static private double grid = 5.0; // 격자간격 (km)
    static private double slat1 = 30.0 * DEGRAD; // 표준위도 1
    static private double slat2 = 60.0 * DEGRAD; // 표준위도 2
    static private double olon = 126.0 * DEGRAD; // 기준점 경도
    static private double olat = 38.0 * DEGRAD; // 기준점 위도
    static private double xo = 210 / grid; // 기준점 X좌표
    static private double yo = 675 / grid; // 기준점 Y좌표
    static private double first = 0;


    static public void lamcproj(double[] input, double[] output, boolean fromWgs84) {
        double re = Re / grid;

        double sn = Math.tan(PI * 0.25 + slat2 * 0.5) / Math.tan(PI * 0.25 + slat1 * 0.5);
        sn = Math.log(Math.cos(slat1) / Math.cos(slat2)) / Math.log(sn);
        double sf = Math.tan(PI * 0.25 + slat1 * 0.5);
        sf = Math.pow(sf, sn) * Math.cos(slat1) / sn;
        double ro = Math.tan(PI * 0.25 + olat * 0.5);
        ro = re * sf / Math.pow(ro, sn);

        if (fromWgs84) {
            double ra = Math.tan(PI * 0.25 + input[1] * DEGRAD * 0.5);
            ra = re * sf / Math.pow(ra, sn);
            double theta = input[0] * DEGRAD - olon;
            if (theta > PI) theta -= 2.0 * PI;
            if (theta < -PI) theta += 2.0 * PI;
            theta *= sn;
            output[0] = (float) (ra * Math.sin(theta)) + xo;
            output[1] = (float) (ro - ra * Math.cos(theta)) + yo;
        } else {
            double xn = input[0] - xo;
            double yn = ro - input[1] + yo;
            double ra = Math.sqrt(xn * xn + yn * yn);
            if (sn < 0.0) ra = -ra;
            double alat = Math.pow((re * sf / ra), (1.0 / sn));
            alat = 2.0 * Math.atan(alat) - PI * 0.5;
            double theta;
            if (Math.abs(xn) <= 0.0) {
                theta = 0.0;
            } else {
                if (Math.abs(yn) <= 0.0) {
                    theta = PI * 0.5;
                    if (xn < 0.0) theta = -theta;
                } else {
                    theta = Math.atan2(xn, yn);
                }
            }
            double alon = theta / sn + olon;

            output[0] = round_down((float) (alon * RADDEG), 7);
            output[1] = round_down((float) (alat * RADDEG), 7);
        }
    }

    private static double round_down(double number, int precision) {
        int fig = (int) Math.pow(10, precision);
        return Math.floor(number * fig) / fig;
    }
}
