package com.example.coronacentermap;

public class CoronaCenterInfo {
    // 예방 접종 센터 고유 식별자
    int id;

    // 예방 접종 센터 명
    String centerName;

    // 시도
    String sido;

    // 시군구
    String sigungu;

    // 시설명
    String facilityName;

    // 우편번호
    String zipCode;

    // 주소
    String address;

    // 좌표(위도)
    String lat;

    // 좌표(경도)
    String lng;

    String createdAt;
    String updatedAt;

    // 예방 접종 센터 유형
    String centerType;

    // 운영기관
    String org;

    // 사무실 전화번호
    String phoneNumber;
}
