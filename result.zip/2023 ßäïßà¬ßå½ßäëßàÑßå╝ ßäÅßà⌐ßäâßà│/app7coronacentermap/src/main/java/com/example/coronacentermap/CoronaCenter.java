package com.example.coronacentermap;

import java.util.List;

public class CoronaCenter {
    int page;
    int perPage;
    int totalCount;
    int currentCount;
    List<CoronaCenterInfo> data;
}
